function phi=basis_func(R,type)
    if strcmp(type,'Gaussian')==1
        phi = exp(-R.^2);
    elseif strcmp(type,'Compactly Supported')==1
        phi = (max((1-R),0)).^4 * (4.*R+1);
    end
end
