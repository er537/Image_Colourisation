function recoverFig = colourised(colourinfo,colourPos,grey,delta,rho,sigma1,sigma2,method)
    wb = waitbar(0,'Coloursing...','WindowStyle','modal');
    %find the location of the colour points
    x=[]; % colour points' position
    gx=[]; % colour points' grey values
    f_R=[];f_G=[];f_B=[]; % colour points' colour values
    [h,w] = size(colourPos);
    for i= 1:h
        for j=1:w
            if colourPos(i,j)>0
                x(end+1,:)=[i,j];
                f_R(end+1,:)=double(colourinfo(i,j,1));
                f_G(end+1,:)=double(colourinfo(i,j,2));
                f_B(end+1,:)=double(colourinfo(i,j,3));
                gx(end+1) = grey(i,j);
            end
        end
    end
    
    % calculate K_D
    Dx = pdist2(x,x);% distant matrix between colour points
    [gx1,gx2] = meshgrid(gx,gx);
    Gx = double(abs(gx1-gx2)); % greyscale gap matrix
    K_D = kernal(Dx,Gx,sigma1,sigma2,rho,method);
    
    % compute the coefficients
    n = size(K_D,1);
    a_R=(K_D+n*delta.*eye(n))\f_R;
    a_G=(K_D+n*delta.*eye(n))\f_G;
    a_B=(K_D+n*delta.*eye(n))\f_B;
    
    % compute colourised matrix to get the colourised figure
    [raw,col] = size(grey);
    rr = 1:1:raw;
    cc = 1:1:col;
    [Ac,Ar] = meshgrid(cc,rr); % position of z(all the points)
    F_R=zeros(raw,col);
    F_G=zeros(raw,col);        
    F_B=zeros(raw,col);
    % This is the procedure of F = K_full*a;
    for j = 1:length(x)
        Dz = ((Ac-x(j,2)).^2+(Ar-x(j,1)).^2).^0.5;
        Gz = double(abs(grey - grey(x(j,1),x(j,2))));
        K_f = kernal(Dz,Gz,sigma1,sigma2,rho,method);
        F_R = F_R + a_R(j).*K_f;
        F_G = F_G + a_G(j).*K_f;
        F_B = F_B + a_B(j).*K_f;
        waitbar(j/n);
    end
    pause(0.2);
    close(wb)
    recoverFig = uint8(cat(3,F_R,F_G,F_B));
end

