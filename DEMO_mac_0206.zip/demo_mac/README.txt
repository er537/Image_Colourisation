Run 'demo.m' file. 
Now the GUI can do:
1. upload different pictures.
2. grescaling
3. generate colour information by 
	uniform: automatically generate colour points uniformly 
	ramdon: automatically generate colour points randomly 
	picked by users: select 'Pick', and users can click points on the 'Color Information'  figure
	drawn by users: select 'Customized', and transfer to a new window where users can draw colour by theirselves
	note: for uniform and ramdon, users can input the proportion of pixels they want to recolour
		for 'Pick', users can input the radius of the 'Pick' points.

