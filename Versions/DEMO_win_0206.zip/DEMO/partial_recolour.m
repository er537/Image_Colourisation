function [P,Color] = partial_recolour(G,C,D)

    % Given a matrix of 1s where you want colour and 0s where
    % you don't produce a partially coloured image
    inv_D = uint8(ones(size(D))-D);
    D = uint8(D);
    Color = D.*C;
    P = inv_D.*G+Color;
end
