
C=imread('angelina.jpg');
proportion=0.001;
delta=2e-4;
p=0.5;
G_triple = greyscale(C);
G=G_triple(:,:,1);
D=uniform_grid(G,proportion);

n=0; %keeps track of the number of colour points
m=0; %total number of points in the matrix

tic
for i= 1:size(D,1)
    for j=1:size(D,2)
        m=m+1;
        z(m,:)=[i j];
        if D(i,j)==1
            n=n+1;
            x(n,:)=[i j];
            f_R(n,:)=double(C(i,j,1));
            f_G(n,:)=double(C(i,j,2));
            f_B(n,:)=double(C(i,j,3));
        end
    end
end
toc

tic
for i=1:n
    for j=1:n
        K_D(i,j)=kernal(x(i,:),x(j,:),100,100,G,p);
    end
end
toc

tic
a_R=(K_D+delta.*eye(n))\f_R;
a_G=(K_D+delta.*eye(n))\f_R;
a_B=(K_D+delta.*eye(n))\f_R;
toc

tic
for i=1:m
    for j=1:n
        K_full(i,j)=kernal(z(i,:),x(j,:),100,100,G,p);
    end
end
toc 

F_R=K_full*a_R;
F_G=K_full*a_R;        
F_B=K_full*a_R;

m=0;
for i=1:size(D,1)
    for j=1:size(D,2)
        m=m+1;
        C_new(i,j,1)=F_R(s);
        C_new(i,j,2)=F_G(s);
        C_new(i,j,3)=F_B(s);
    end
end

imshow(C2);
 




