function phi=basis_func(r)
    phi=(max((1-r),0))^4 * (4*r+1);
end
