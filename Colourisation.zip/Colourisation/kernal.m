function K = kernal(x,y,sigma1,sigma2,G,p)
    
    gamma_x=G(x(1,1),x(1,2)); %eg G(i,j) which is the greyscale information at the chosen point 
    gamma_y=G(y(1,1),y(1,2));
    absolute=double(abs(gamma_x-gamma_y));
    K=basis_func((norm(x-y,2))/sigma1) * basis_func((sqrt(absolute))/sigma2);
end