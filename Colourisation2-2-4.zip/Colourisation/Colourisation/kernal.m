function K = kernal(R,Gx,sigma1,sigma2,p,type)
    dg = Gx.^p./sigma2;
    R = R./sigma1;
    K = basis_func(R,type).*basis_func(dg,type);
end