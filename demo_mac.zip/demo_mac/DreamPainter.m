function varargout = DreamPainter(varargin)
% DREAMPAINTER MATLAB code for DreamPainter.fig
%      DREAMPAINTER, by itself, creates a new DREAMPAINTER or raises the existing
%      singleton*.
%
%      H = DREAMPAINTER returns the handle to a new DREAMPAINTER or the handle to
%      the existing singleton*.
%
%      DREAMPAINTER('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in DREAMPAINTER.M with the given input arguments.
%
%      DREAMPAINTER('Property','Value',...) creates a new DREAMPAINTER or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before DreamPainter_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to DreamPainter_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help DreamPainter

% Last Modified by GUIDE v2.5 29-Jan-2021 22:29:42

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @DreamPainter_OpeningFcn, ...
                   'gui_OutputFcn',  @DreamPainter_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before DreamPainter is made visible.
function DreamPainter_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to DreamPainter (see VARARGIN)

% Choose default command line output for DreamPainter
handles.output = hObject;
global ButtonDown pos;
ButtonDown = [];
pos = [];
handles.demo = varargin{:};
[y,x] = size(handles.demo.greyscaleFig(:,:,1));
bound = ones(y,x);
bound(:,1) = 0;bound(:,end) = 0;bound(end,:) = 0;bound(1,:) = 0;
boundary = cat(3,bound,bound,bound);
imshow(boundary,'parent',handles.axes2);
blackCanvas = zeros(size(bound));
imshow(blackCanvas,'parent',handles.axes3);
axes(handles.axes1)
imshow(handles.demo.greyscaleFig,'parent',handles.axes1);
global LineColor;
LineColor = [1 1 1];
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes DreamPainter wait for user response (see UIRESUME)
uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = DreamPainter_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;
delete(handles.figure1);

% --- Executes on button press in colour_btn.
function colour_btn_Callback(hObject, eventdata, handles)
% hObject    handle to colour_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global LineColor;
temp = uisetcolor;
if length(temp(:))~=1
    LineColor = temp;
end

% --- Executes on button press in save_btn.
function save_btn_Callback(hObject, eventdata, handles)
% hObject    handle to save_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
try 
    delete(allchild(handles.axes2));
end
haFig=getframe(handles.axes1);
try 
    delete(allchild(handles.axes1));
end
haColorinfo = getframe(handles.axes3);
handles.output = {imresize(haFig.cdata, size(handles.demo.greyscaleFig(:,:,1)));...
                 imresize(haColorinfo.cdata, size(handles.demo.greyscaleFig(:,:,1))) };
guidata(hObject, handles);
uiresume(handles.figure1);


% --- Executes on button press in cancel_btn.
function cancel_btn_Callback(hObject, eventdata, handles)
% hObject    handle to cancel_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.output = [];
guidata(hObject,handles);
uiresume(handles.figure1)

% --- Executes on mouse press over figure background, over a disabled or
% --- inactive control, or over an axes background.
function figure1_WindowButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global ButtonDown pos;
if strcmp(get(gcf,'SelectionType'),'normal')
    ButtonDown = 1;
    pos = get(handles.axes1,'CurrentPoint');
end

% --- Executes on mouse motion over figure - except title and menu.
function figure1_WindowButtonMotionFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global ButtonDown pos;
global LineColor;
if ButtonDown == 1
    pos1 = get(handles.axes1,'CurrentPoint');
    line(handles.axes1,[pos(1,1) pos1(1,1)],[pos(1,2) pos1(1,2)],'LineWidth',2,'color',LineColor);
    line(handles.axes3,[pos(1,1) pos1(1,1)],[pos(1,2) pos1(1,2)],'LineWidth',2,'color',LineColor);
    pos = pos1;
end

% --- Executes on mouse press over figure background, over a disabled or
% --- inactive control, or over an axes background.
function figure1_WindowButtonUpFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global ButtonDown
ButtonDown = 0;


% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.output = [];
guidata(hObject,handles);
uiresume(handles.figure1);
% Hint: delete(hObject) closes the figure
%delete(hObject);
