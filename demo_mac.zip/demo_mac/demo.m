function varargout = demo(varargin)
% DEMO MATLAB code for demo.fig
%      DEMO, by itself, creates a new DEMO or raises the existing
%      singleton*.
%
%      H = DEMO returns the handle to a new DEMO or the handle to
%      the existing singleton*.
%
%      DEMO('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in DEMO.M with the given input arguments.
%
%      DEMO('Property','Value',...) creates a new DEMO or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before demo_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to demo_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help demo

% Last Modified by GUIDE v2.5 30-Jan-2021 12:43:55

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @demo_OpeningFcn, ...
                   'gui_OutputFcn',  @demo_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before demo is made visible.
function demo_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to demo (see VARARGIN)

% Choose default command line output for demo
handles.output = hObject;
handles.originFig = []; % triple of the original picture
handles.greyscaleFig = []; % triple of the original picture
handles.colorinfoFig = []; % triple of the original picture
handles.recoverFig = []; % triple of the original picture
handles.recolourChoice=[]; % the type of recolour chosen by users 
handles.proportion_etxt=str2double(get(handles.proportion_etxt,'String'))/100; % the % values of pixels need to be recolored 
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes demo wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = demo_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in upload_btn.
function upload_btn_Callback(hObject, eventdata, handles)
% hObject    handle to upload_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% upload pictures
[filename,pathname,flag] = uigetfile({'*.*';'*.jpg';'*.bmp';'*.gif';'*.png';'*.tif'},'Read Pic');
str = [pathname filename];
if (flag~=0)
    % store original picture in handles.originFig
    handles.originFig = imread(str);
    axes(handles.origin_axes);
    imshow(handles.originFig);
    % greyscaling and store greyscaled picture in handles.greyscaleFig
    handles.greyscaleFig=greyscale(handles.originFig);
    axes(handles.greyscale_axes);
    imshow(handles.greyscaleFig);
    guidata(hObject, handles);
end

% --- Executes on button press in colorinfo_btn.
function colorinfo_btn_Callback(hObject, eventdata, handles)
% hObject    handle to colorinfo_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if strcmp(handles.recolourChoice,'Uniform')
    % D is the position matrix we want to recolor
    D = uniform_grid(handles.greyscaleFig,handles.proportion_etxt);
    % 'temp' is the color+grey points. 'handles.colorinfoFig' is the color points
    [temp,handles.colorinfoFig] = partial_recolour(handles.greyscaleFig,handles.originFig,D);
    axes(handles.colorinfo_axes);
    imshow(temp);
    imshow(handles.colorinfoFig,'parent',handles.recover_axes)
elseif strcmp(handles.recolourChoice,'Random')
    D = random_grid(handles.greyscaleFig,handles.proportion_etxt);
    [temp,handles.colorinfoFig] = partial_recolour(handles.greyscaleFig,handles.originFig,D);
    axes(handles.colorinfo_axes);
    imshow(temp);
    imshow(handles.colorinfoFig,'parent',handles.recover_axes)
elseif strcmp(handles.recolourChoice,'Pick')
    axes(handles.colorinfo_axes);
    handles.colorinfoPlot = handles.greyscaleFig;
    handles.colorinfoImage = imshow(handles.colorinfoPlot);
    handles.colorinfoFig = zeros(size(handles.greyscaleFig));
    set(handles.colorinfoImage,'ButtonDownFcn',{@ImageClickCallback,hObject}) 
    imshow(handles.colorinfoFig,'parent',handles.recover_axes)
elseif strcmp(handles.recolourChoice,'Customized')
    % tranfer to another window, 'DreamPainter'
    temp = DreamPainter(handles);
    if(~isempty(temp))
        handles.colorinfoFig = cell2mat(temp(2)); % triple of only color points
        temp = cell2mat(temp(1)); % triple of color+greyscale points
        imshow(temp,'parent',handles.colorinfo_axes);
        imshow(handles.colorinfoFig,'parent',handles.recover_axes)
    end
end
guidata(hObject, handles);

function ImageClickCallback(eventdata, handles,hObject)
    handles=guidata(hObject);  %EDIT
    pos=get(gca,'CurrentPoint');
    coordinates(1)=floor(pos(1,1));
    coordinates(2)=floor(pos(1,2));
    D = customised_grid(handles.greyscaleFig,coordinates,str2double(get(handles.radius_etxt,'String')));
    % 'temp' is the currently picked points. 'handles.colorinfoPlot' is the color+grey points
    [handles.colorinfoPlot,temp] = partial_recolour(handles.colorinfoPlot,handles.originFig,D);
    % add the currently picked points into the previously picked points matrix.
    T =temp>0;
    invT = uint8(ones(size(T))-T);
    T = uint8(T);
    handles.colorinfoFig = invT.*uint8(handles.colorinfoFig)+T.*temp;
    axes(handles.colorinfo_axes);
    handles.colorinfoImage=imshow(handles.colorinfoPlot);
    set(handles.colorinfoImage,'ButtonDownFcn',{@ImageClickCallback,hObject});
    imshow(handles.colorinfoFig,'parent',handles.recover_axes)
    guidata(hObject,handles);

function proportion_etxt_Callback(hObject, eventdata, handles)
% hObject    handle to proportion_etxt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of proportion_etxt as text
%        str2double(get(hObject,'String')) returns contents of proportion_etxt as a double
handles.proportion_etxt = str2double(get(hObject,'String'))/100;
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function proportion_etxt_CreateFcn(hObject, eventdata, handles)
% hObject    handle to proportion_etxt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in colorinfo_pum.
function colorinfo_pum_Callback(hObject, eventdata, handles)
% hObject    handle to colorinfo_pum (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns colorinfo_pum contents as cell array
%        contents{get(hObject,'Value')} returns selected item from colorinfo_pum
handles.recolourChoice = hObject.String{hObject.Value};
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function colorinfo_pum_CreateFcn(hObject, eventdata, handles)
% hObject    handle to colorinfo_pum (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
global COM_GREYSCALE;
% selection of types of greyscale
COM_GREYSCALE = {'--Please Select--','Uniform','Random','Pick','Customized'};
set(hObject,'String',COM_GREYSCALE);


function radius_etxt_Callback(hObject, eventdata, handles)
% hObject    handle to radius_etxt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of radius_etxt as text
%        str2double(get(hObject,'String')) returns contents of radius_etxt as a double


% --- Executes during object creation, after setting all properties.
function radius_etxt_CreateFcn(hObject, eventdata, handles)
% hObject    handle to radius_etxt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on mouse press over axes background.
function colorinfo_axes_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to colorinfo_axes (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
hObject.currentPoint;
