function K = kernal(R,Gx,sigma1,sigma2,p,method)
    dg = Gx.^p./sigma2;
    R = R./sigma1;
    K = basis_func(R,method).*basis_func(dg,method);
end