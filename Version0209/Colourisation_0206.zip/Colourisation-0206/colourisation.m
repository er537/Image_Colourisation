clear,clc,close all
%input colorinfoFig, greyscaleFig
C=imread('Peppa.jpg');
proportion=0.02;
delta=2e-5;
p=0.5;
greyscaleFig = greyscale(C);
G=greyscaleFig(:,:,1);
D=uniform_grid(G,proportion);
type = 'Gaussian';
g = [];
sigma1 = 100;
sigma2 = 100;

n=0; %keeps track of the number of colour points
tic
for i= 1:size(D,1)
    for j=1:size(D,2)
        if D(i,j)==1
            n=n+1;
            x(n,:)=[i j];
            f_R(n,:)=double(C(i,j,1));
            f_G(n,:)=double(C(i,j,2));
            f_B(n,:)=double(C(i,j,3));
            g(end+1) = G(i,j);
        end
    end
end
toc

tic
% calculate K_D
Rx = pdist2(x,x);% distant matrix between colour points
[gx1,gx2] = meshgrid(g,g);
Gx = double(abs(gx1-gx2)); % greyscale gap matrix
K_D = kernal(Rx,Gx,sigma1,sigma2,p,type);
toc

% coefficient
a_R=(K_D+n*delta.*eye(n))\f_R;
a_G=(K_D+n*delta.*eye(n))\f_G;
a_B=(K_D+n*delta.*eye(n))\f_B;


[k,l] = size(D);
xx = 1:1:l;
yy = 1:1:k;
[Ay,Ax] = meshgrid(xx,yy); % position of z(all the points)
F_R=zeros(size(D));
F_G=zeros(size(D));        
F_B=zeros(size(D));
tic
hww = waitbar(0);
for j = 1:n
    waitbar(j/n);
    R = ((Ay-x(j,2)).^2+(Ax-x(j,1)).^2).^0.5;
    Gz = double(abs(G - G(x(j,1),x(j,2))));
    KK = kernal(R,Gz,sigma1,sigma2,p,type);
    F_R = F_R + a_R(j).*KK;
    F_G = F_G + a_G(j).*KK;
    F_B = F_B + a_B(j).*KK;
end
toc
close(hww)
C2 = cat(3,F_R,F_G,F_B);
C2 = uint8(C2);
imshow(C2);
 




