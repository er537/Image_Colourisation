function K = kernal(D,G,sigma1,sigma2,rho,method)
    dg = G.^rho./sigma2;
    D = D./sigma1;
    K = basis_func(D,method).*basis_func(dg,method);
end