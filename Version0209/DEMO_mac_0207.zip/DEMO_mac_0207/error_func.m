function [error_func,grey_rec] = error_func(C,G,D,y,Type) %Type can either be 'Grey Error' or 'Colour Error'

    delta=y(1);
    p=y(2);
    sigma1 = y(3);
    sigma2 = y(4);

    g = [];
    type = 'Gaussian';

    n=0; %keeps track of the number of colour points
    m = 0; %keeps track of total number of points
    for i= 1:size(D,1)
        for j=1:size(D,2)
            m = m+1;
            if D(i,j)==1
                n=n+1;
                x(n,:)=[i j];
                f_R(n,:)=double(C(i,j,1));
                f_G(n,:)=double(C(i,j,2));
                f_B(n,:)=double(C(i,j,3));
                g(n,:) = G(i,j);
            end
        end
    end

    % calculate K_D
    Rx = pdist2(x,x);% distant matrix between colour points
    [gx1,gx2] = meshgrid(g,g);
    Gx = double(abs(gx1-gx2)); % greyscale gap matrix
    K_D = kernal(Rx,Gx,sigma1,sigma2,p,type);


    % coefficient
    a_R=(K_D+n*delta.*eye(n))\f_R;
    a_G=(K_D+n*delta.*eye(n))\f_G;
    a_B=(K_D+n*delta.*eye(n))\f_B;


    [k,l] = size(D);
    xx = 1:1:l;
    yy = 1:1:k;
    [Ay,Ax] = meshgrid(xx,yy); % position of z(all the points)
    F_R=zeros(size(D));
    F_G=zeros(size(D));        
    F_B=zeros(size(D));

    for j = 1:n
        R = ((Ay-x(j,2)).^2+(Ax-x(j,1)).^2).^0.5;
        Gz = double(abs(G - G(x(j,1),x(j,2))));
        KK = kernal(R,Gz,sigma1,sigma2,p,type);
        F_R = F_R + a_R(j).*KK;
        F_G = F_G + a_G(j).*KK;
        F_B = F_B + a_B(j).*KK;
    end
    
    if strcmp(Type,'Colour Error')
        if abs(delta) <= 0.001 && abs(p)<=1 && 50<=abs(sigma1) && abs(sigma1)<=150 && 50<=abs(sigma2) && abs(sigma2)<=150
            error_func = sqrt((norm(F_R-double(C(:,:,1)),'fro')^2+norm(F_G-double(C(:,:,2)),'fro')^2+norm(F_B-double(C(:,:,3)),'fro')^2))/(3*m);
        else
            error_func = 10000;
        end
    else
        if strcmp(Type,'Grey Error')
            recoverFig = uint8(cat(3,F_R,F_G,F_B));
            grey_rec = rgb2gray(recoverFig);
            if abs(delta) <= 0.001 && abs(p)<=1 && 50<=abs(sigma1) && abs(sigma1)<=150 && 50<=abs(sigma2) && abs(sigma2)<=150
                error_func = norm(double(grey_rec-G),'fro')/sqrt(m);
            else
                error_func = 10000;
            end
        else
        disp('Please enter either char(39)Colour Errorchar(39) or char(39)Grey Errorchar(39)') 
        end
    end
    
  end