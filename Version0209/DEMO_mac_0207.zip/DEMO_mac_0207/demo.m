function varargout = demo(varargin)
% DEMO MATLAB code for demo.fig
%      DEMO, by itself, creates a new DEMO or raises the existing
%      singleton*.
%
%      H = DEMO returns the handle to a new DEMO or the handle to
%      the existing singleton*.
%
%      DEMO('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in DEMO.M with the given input arguments.
%
%      DEMO('Property','Value',...) creates a new DEMO or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before demo_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to demo_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help demo

% Last Modified by GUIDE v2.5 09-Feb-2021 14:18:15

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @demo_OpeningFcn, ...
                   'gui_OutputFcn',  @demo_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before demo is made visible.
function demo_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to demo (see VARARGIN)

% Choose default command line output for demo
handles.output = hObject;
handles.originFig = []; % triple of the original picture
handles.greyscaleFig = []; % triple of the original picture
handles.colorinfoFig = []; % triple of the original picture
handles.colorPos = []; % record the location of colour point in this matrix (1 is valid)
handles.recoverFig = []; % triple of the original picture
handles.recolourChoice=[]; % the type of recolour chosen by users 
handles.proportion_etxt=str2double(get(handles.proportion_etxt,'String'))/100; % the % values of pexels need to be recolored 
handles.delta = 2e-4; % parameter of colourisation
handles.sigma1 = 100; % parameter of colourisation
handles.sigma2 = 100; % parameter of colourisation
handles.rho = 0.5; % parameter of colourisation
handles.method = 'Gaussian'; % parameter of colourisation

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes demo wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = demo_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in upload_btn.
function upload_btn_Callback(hObject, eventdata, handles)
% hObject    handle to upload_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% upload pictures
[filename,pathname,flag] = uigetfile({'*.*';'*.jpg';'*.bmp';'*.gif';'*.png';'*.tif'},'Read Pic');
str = [pathname filename];
if (flag~=0)
    % store original picture in handles.originFig
    handles.originFig = imread(str);
    axes(handles.origin_axes);
    imshow(handles.originFig);
    % greyscaling and store greyscaled picture in handles.greyscaleFig
    handles.greyscaleFig=greyscale(handles.originFig);
    axes(handles.greyscale_axes);
    imshow(handles.greyscaleFig);
    guidata(hObject, handles);
end

% --- Executes on button press in colorinfo_btn.
function colorinfo_btn_Callback(hObject, eventdata, handles)
% hObject    handle to colorinfo_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if strcmp(handles.recolourChoice,'Uniform')
    handles.colorPos = uniform_grid(handles.greyscaleFig,handles.proportion_etxt);
    % 'temp' is the color+grey points. 'handles.colorinfoFig' is the color points
    [temp,handles.colorinfoFig] = partial_recolour(handles.greyscaleFig,handles.originFig,handles.colorPos);
    axes(handles.colorinfo_axes);
    imshow(temp);
    imshow(handles.colorinfoFig,'parent',handles.recover_axes)
elseif strcmp(handles.recolourChoice,'Random')
    handles.colorPos = random_grid(handles.greyscaleFig,handles.proportion_etxt);
    [temp,handles.colorinfoFig] = partial_recolour(handles.greyscaleFig,handles.originFig,handles.colorPos);
    axes(handles.colorinfo_axes);
    imshow(temp);
    imshow(handles.colorinfoFig,'parent',handles.recover_axes)
elseif strcmp(handles.recolourChoice,'Pick')
    axes(handles.colorinfo_axes);
    handles.colorinfoPlot = handles.greyscaleFig;
    handles.colorinfoImage = imshow(handles.colorinfoPlot);
    handles.colorinfoFig = zeros(size(handles.greyscaleFig));
    set(handles.colorinfoImage,'ButtonDownFcn',{@ImageClickCallback,hObject}) 
    imshow(handles.colorinfoFig,'parent',handles.recover_axes)
elseif strcmp(handles.recolourChoice,'Customized')
    % tranfer to another window, 'DreamPainter'
    temp = DreamPainter(handles);
    if(~isempty(temp))
        handles.colorinfoFig = cell2mat(temp(2)); % triple of only color points
        handles.colorPos = sum(handles.colorinfoFig,3);
        handles.colorPos(handles.colorPos>0) = 1;
        temp = cell2mat(temp(1)); % triple of color+greyscale points
        imshow(temp,'parent',handles.colorinfo_axes);
        imshow(handles.colorinfoFig,'parent',handles.recover_axes)
    end
end
guidata(hObject, handles);

function ImageClickCallback(eventdata, handles,hObject)
    handles=guidata(hObject);  %EDIT
    pos=get(gca,'CurrentPoint');
    coordinates(1)=floor(pos(1,1));
    coordinates(2)=floor(pos(1,2));
    D = customised_grid(handles.greyscaleFig,coordinates,str2double(get(handles.radius_etxt,'String')));
    if isempty(handles.colorPos)==1
        handles.colorPos = D;
    else
        handles.colorPos = xor(handles.colorPos,D);
    end
    % 'temp' is the currently picked points. 'handles.colorinfoPlot' is the color+grey points
    [handles.colorinfoPlot,temp] = partial_recolour(handles.colorinfoPlot,handles.originFig,D);
    % add the currently picked points into the previously picked points matrix.
    T =temp>0;
    invT = uint8(ones(size(T))-T);
    T = uint8(T);
    handles.colorinfoFig = invT.*uint8(handles.colorinfoFig)+T.*temp;
    axes(handles.colorinfo_axes);
    handles.colorinfoImage=imshow(handles.colorinfoPlot);
    set(handles.colorinfoImage,'ButtonDownFcn',{@ImageClickCallback,hObject});
    imshow(handles.colorinfoFig,'parent',handles.recover_axes)
    guidata(hObject,handles);

function proportion_etxt_Callback(hObject, eventdata, handles)
% hObject    handle to proportion_etxt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of proportion_etxt as text
%        str2double(get(hObject,'String')) returns contents of proportion_etxt as a double
handles.proportion_etxt = str2double(get(hObject,'String'))/100;
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function proportion_etxt_CreateFcn(hObject, eventdata, handles)
% hObject    handle to proportion_etxt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in colorinfo_pum.
function colorinfo_pum_Callback(hObject, eventdata, handles)
% hObject    handle to colorinfo_pum (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns colorinfo_pum contents as cell array
%        contents{get(hObject,'Value')} returns selected item from colorinfo_pum
handles.recolourChoice = hObject.String{hObject.Value};
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function colorinfo_pum_CreateFcn(hObject, eventdata, handles)
% hObject    handle to colorinfo_pum (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
global COM_GREYSCALE;
% selection of types of greyscale
%'Customized' mode has bug for mac PC, but nice for windows.
COM_GREYSCALE = {'--Please Select--','Uniform','Random','Pick'};%'Customized'};
set(hObject,'String',COM_GREYSCALE);


function radius_etxt_Callback(hObject, eventdata, handles)
% hObject    handle to radius_etxt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of radius_etxt as text
%        str2double(get(hObject,'String')) returns contents of radius_etxt as a double


% --- Executes during object creation, after setting all properties.
function radius_etxt_CreateFcn(hObject, eventdata, handles)
% hObject    handle to radius_etxt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on mouse press over axes background.
function colorinfo_axes_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to colorinfo_axes (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
hObject.currentPoint;


% --- Executes on button press in colourisation_btn.
function colourisation_btn_Callback(hObject, eventdata, handles)
% hObject    handle to colourisation_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.delta = str2double(get(handles.delta_etxt,'String'));
handles.sigma1 = str2double(get(handles.sigma1_etxt,'String'));
handles.sigma2 = str2double(get(handles.sigma2_etxt,'String'));
handles.rho = str2double(get(handles.rho_etxt,'String'));
handles.method = get(handles.method_pum,'String');
handles.recoverFig = colourised(handles.colorinfoFig,handles.colorPos,handles.greyscaleFig(:,:,1),...
    handles.delta,handles.rho,handles.sigma1,handles.sigma2,handles.method);
imshow(handles.recoverFig,'parent',handles.recover_axes);
guidata(hObject,handles);

function delta_etxt_Callback(hObject, eventdata, handles)
% hObject    handle to delta_etxt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of delta_etxt as text
%        str2double(get(hObject,'String')) returns contents of delta_etxt as a double


% --- Executes during object creation, after setting all properties.
function delta_etxt_CreateFcn(hObject, eventdata, handles)
% hObject    handle to delta_etxt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function sigma1_etxt_Callback(hObject, eventdata, handles)
% hObject    handle to sigma1_etxt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of sigma1_etxt as text
%        str2double(get(hObject,'String')) returns contents of sigma1_etxt as a double


% --- Executes during object creation, after setting all properties.
function sigma1_etxt_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sigma1_etxt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function sigma2_etxt_Callback(hObject, eventdata, handles)
% hObject    handle to sigma2_etxt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of sigma2_etxt as text
%        str2double(get(hObject,'String')) returns contents of sigma2_etxt as a double


% --- Executes during object creation, after setting all properties.
function sigma2_etxt_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sigma2_etxt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function rho_etxt_Callback(hObject, eventdata, handles)
% hObject    handle to rho_etxt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of rho_etxt as text
%        str2double(get(hObject,'String')) returns contents of rho_etxt as a double


% --- Executes during object creation, after setting all properties.
function rho_etxt_CreateFcn(hObject, eventdata, handles)
% hObject    handle to rho_etxt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in method_pum.
function method_pum_Callback(hObject, eventdata, handles)
% hObject    handle to method_pum (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns method_pum contents as cell array
%        contents{get(hObject,'Value')} returns selected item from method_pum


% --- Executes during object creation, after setting all properties.
function method_pum_CreateFcn(hObject, eventdata, handles)
% hObject    handle to method_pum (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
global COM_METHOD;
% selection of types of greyscale
COM_METHOD = {'--Please Select--','Gaussian','Compactly Supported'};
set(hObject,'String',COM_METHOD);


% --- Executes on button press in color_save_btn.
function color_save_btn_Callback(hObject, eventdata, handles)
% hObject    handle to color_save_btn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
filter={'*.jpg';'*.png';'*.*'};
[file,path,indx] = uiputfile(filter);
if indx ~=0
    imwrite(handles.recoverFig,fullfile(path,file))
end
