function D = customised_grid(G,coordinates,r)

    G_size = size(G);
    D = zeros(G_size(1),G_size(2));
    A = ones(1+min(G_size(1),coordinates(2)+r)-max(1,coordinates(2)-r),1+min(G_size(2),coordinates(1)+r)-max(1,coordinates(1)-r));
    D(max(1,coordinates(2)-r):min(G_size(1),coordinates(2)+r),max(1,coordinates(1)-r):min(G_size(2),coordinates(1)+r))=ones(size(A));

end