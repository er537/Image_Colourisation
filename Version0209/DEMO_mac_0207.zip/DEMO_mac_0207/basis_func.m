function phi=basis_func(D,method)
    if strcmp(method,'Gaussian')==1
        phi = exp(-D.^2);
    elseif strcmp(method,'Compactly Supported')==1
        phi = (max((1-D),0)).^4 * (4.*D+1);
    else
        phi = basis_func(D,'Gaussian');
    end
end
